"""
MASI task configuration variants (e.g., IK-based control).
"""

