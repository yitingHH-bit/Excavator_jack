# ------- 在 rewards.py 中替换 ee_to_log_distance -------

from __future__ import annotations
import torch
from isaaclab.managers import SceneEntityCfg
from isaaclab.utils.math import matrix_from_quat  # 仍然可用

# 如果你文件里已经有 _safe / _safe_div / _get_env_origins，就不要重复定义
def _safe(x: torch.Tensor, name: str = "") -> torch.Tensor:
    x = torch.nan_to_num(x, nan=0.0, posinf=1e6, neginf=-1e6)
    return torch.clamp(x, -1e3, 1e3)

def _safe_div(num: torch.Tensor, den: torch.Tensor) -> torch.Tensor:
    return num / (den + 1e-8)

def _get_env_origins(env) -> torch.Tensor:
    origins = env.scene.env_origins
    return origins if isinstance(origins, torch.Tensor) else torch.as_tensor(origins, device=env.device)

def ee_to_log_distance(
    env,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    log_cfg: SceneEntityCfg   = SceneEntityCfg("log"),
    ee_body_name: str         = "gripper_frame",
    ee_offset_local: tuple[float, float, float] = (0.0, 0.0, -0.115),
    use_l2: bool = True,
    shaped: bool = True,
    scale: float = 0.25,
) -> torch.Tensor:
    """有界奖励（0~1，越近越接近 1）或负距离（越近越大），兼容你这版张量结构。"""
    device = env.device
    origins = _get_env_origins(env)  # (N,3)

    robot = env.scene[robot_cfg.name]
    log   = env.scene[log_cfg.name]

    # —— 取 body 索引（按名字解析一次即可）——
    body_ids, _ = robot.find_bodies([ee_body_name])
    ee_idx = int(body_ids[0])  # 单个名字，取第 0 个

    # —— 世界系 EE 位姿（按张量维度取，不用 rigid_body_frame）——
    # 形状通常是 (N, num_bodies, 3/4)
    ee_pos_w  = robot.data.body_link_pos_w[:, ee_idx, :]     # (N,3)
    ee_quat_w = robot.data.body_link_quat_w[:, ee_idx, :]    # (N,4)

    # 把局部 offset 旋转到世界并相加
    R_ee = matrix_from_quat(ee_quat_w)                       # (N,3,3)
    ee_off = torch.as_tensor(ee_offset_local, device=device, dtype=ee_pos_w.dtype).view(1,3,1)
    ee_pos_w = ee_pos_w + (R_ee @ ee_off).squeeze(-1)        # (N,3)

    # —— 世界系 LOG 根位置（不同版本 shape 可能是 (N,3) 或 (N,1,3)）——
    log_root = log.data.root_pos_w
    if log_root.ndim == 2:       # (N,3)
        log_pos_w = log_root
    elif log_root.ndim == 3:     # (N,1,3) 或 (N,K,3)
        log_pos_w = log_root[:, 0, :]
    else:
        # 极端兜底
        log_pos_w = log_root.reshape(log_root.shape[0], -1)[..., :3]

    # —— 转各自 env 局部坐标，避免巨大 world 偏移 —— 
    ee_pos_local  = ee_pos_w  - origins
    log_pos_local = log_pos_w - origins

    # —— 距离计算 —— 
    d = _safe(ee_pos_local - log_pos_local, "d_vec")
    dist = torch.linalg.norm(d, dim=1) if use_l2 else torch.sum(torch.abs(d), dim=1)
    dist = _safe(dist, "dist")

    # —— 形状化/原始奖励 —— 
    if shaped:
        rew = 1.0 - torch.tanh(_safe_div(dist, torch.as_tensor(scale, device=device)))
        return _safe(rew, "ee2log_shaped")
    else:
        rew = -_safe_div(dist, torch.as_tensor(scale, device=device))
        return _safe(rew, "ee2log_raw")
