# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

from __future__ import annotations

import torch
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedRLEnv


def position_command_error_tanh(env: ManagerBasedRLEnv, std: float, command_name: str) -> torch.Tensor:
    """Reward position tracking with tanh kernel."""
    command = env.command_manager.get_command(command_name)
    des_pos_b = command[:, :3]
    distance = torch.norm(des_pos_b, dim=1)
    return 1 - torch.tanh(distance / std)


def heading_command_error_abs(env: ManagerBasedRLEnv, command_name: str) -> torch.Tensor:
    """Penalize tracking orientation error."""
    command = env.command_manager.get_command(command_name)
    heading_b = command[:, 3]
    return heading_b.abs()



# mdp.py 里加上：
import torch
from isaaclab.envs import ManagerBasedEnv

def auto_grasp_log_fsm(
    env: ManagerBasedEnv,
    env_ids: torch.Tensor | None = None,
    *,
    robot_name: str = "robot",
    ee_body_name: str = "gripper_frame",
    log_name: str = "log",
    close_xy_dist: float = 0.08,   # 爪子在水平距离多少米内算“接近木头”
    close_z_tol: float = 0.03,     # 垂直高度差容忍（EE 高度 ≈ 木头高度）
) -> torch.Tensor:
    """
    非学习的“规则抓取”：根据 ee 和 log 的相对位置，决定爪子应该张开(0)还是闭合(1)。

    - 只要满足：
        1) ee 在 log 上方附近（水平距离 < close_xy_dist）
        2) ee 的 z 高度和 log 差不多（abs(dz) < close_z_tol）
      就返回 1.0（闭合爪子）
    - 否则返回 0.0（张开爪子）

    你可以在训练脚本里这样用：
        raw_actions = policy(obs)
        auto_grip = auto_grasp_log_fsm(env)          # [num_envs]
        raw_actions[:, grip_index] = auto_grip       # 覆盖动作里的爪子维度
        obs, rew, done, info = env.step(raw_actions)
    """
    device = env.device
    num_envs = env.num_envs

    # 1) 处理 env_ids（如果没给，就对所有 env 生效）
    if env_ids is None:
        env_ids = torch.arange(num_envs, device=device, dtype=torch.long)
    elif isinstance(env_ids, slice):
        env_ids = torch.arange(num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        # 保证是 LongTensor
        env_ids = env_ids.to(device=device, dtype=torch.long)

    if env_ids.numel() == 0:
        # 没有需要处理的 env，就直接返回全 0（张开）
        return torch.zeros(num_envs, device=device, dtype=torch.float32)

    # 2) 取出机器人和木头
    robot = env.scene.articulations[robot_name]
    log_obj = env.scene.rigid_objects[log_name]

    # 3) 找到末端 link 在 body_state_w 里的 index（只算一次，缓存到 env 上）
    if not hasattr(env, "_excavator_ee_body_index"):
        body_names = robot.data.body_names
        try:
            ee_idx = body_names.index(ee_body_name)
        except ValueError as exc:
            raise RuntimeError(
                f"[auto_grasp_log_fsm] body '{ee_body_name}' 不在 robot.body_names 里，"
                f"当前 body_names = {body_names}"
            ) from exc
        env._excavator_ee_body_index = ee_idx

    ee_idx: int = env._excavator_ee_body_index

    # 4) 读取 ee 与 log 的世界坐标
    # robot.data.body_state_w: [num_envs, num_bodies, 13]  ->  pos(3), quat(4), lin_vel(3), ang_vel(3)
    ee_state = robot.data.body_state_w[env_ids, ee_idx]   # [N, 13]
    ee_pos = ee_state[:, 0:3]                             # [N, 3]

    # log 只有一个 root body
    log_state = log_obj.data.root_state_w[env_ids]        # [N, 13]
    log_pos = log_state[:, 0:3]                           # [N, 3]

    # 5) 计算相对位置：log - ee
    delta = log_pos - ee_pos                              # [N, 3]
    d_xy = torch.linalg.norm(delta[:, :2], dim=-1)        # 水平距离
    dz = delta[:, 2]                                      # z 方向差

    # 6) 简单规则：靠近并且高度差不大 -> 闭合
    close_mask = (d_xy < close_xy_dist) & (dz.abs() < close_z_tol)

    # 返回形状为 [num_envs] 的动作（0 = open, 1 = close）
    gripper_cmd = torch.zeros(num_envs, device=device, dtype=torch.float32)
    if close_mask.any():
        # env_ids 是 subset，所以要先选 subset，再映射回全局 env index
        grasp_env_ids = env_ids[close_mask]  # 这些 env 需要闭合
        gripper_cmd[grasp_env_ids] = 1.0

    return gripper_cmd
