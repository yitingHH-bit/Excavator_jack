from dataclasses import MISSING

import isaaclab.sim as sim_utils
from isaaclab.assets import ArticulationCfg, AssetBaseCfg, RigidObjectCfg
from isaaclab.controllers.differential_ik_cfg import DifferentialIKControllerCfg
from isaaclab.envs import ManagerBasedRLEnvCfg
from isaaclab.envs.mdp.actions.actions_cfg import DifferentialInverseKinematicsActionCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import RewardTermCfg as RewTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.utils import configclass
import isaaclab_tasks.manager_based.manipulation.reach.mdp as mdp_isaac
from isaaclab_assets.robots.masiV0 import MASI_CFG

from .. import mdp


@configclass
class MasiLogSceneCfg(InteractiveSceneCfg):
    """Scene with MASI and a simple log object to reach."""

    robot: ArticulationCfg = MISSING
    log: RigidObjectCfg = RigidObjectCfg(
        prim_path="{ENV_REGEX_NS}/Log",
        spawn=sim_utils.CuboidCfg(
            size=(0.06, 0.20, 0.06),
            rigid_props=sim_utils.RigidBodyPropertiesCfg(
                max_linear_velocity=10.0,    # m/s
                max_angular_velocity=30.0,
            ),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.100),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.1, 0.0)),
        ),
        # place on ground: center at z ~ half thickness (0.03)
        init_state=RigidObjectCfg.InitialStateCfg(pos=(0.6, 0.0, 0.03), rot=(1.0, 0.0, 0.0, 0.0)),
    )

    plane = AssetBaseCfg(
        prim_path="/World/GroundPlane",
        init_state=AssetBaseCfg.InitialStateCfg(),
        spawn=sim_utils.GroundPlaneCfg(),
    )

    light = AssetBaseCfg(
        prim_path="/World/Light",
        spawn=sim_utils.DomeLightCfg(intensity=3000.0, color=(0.75, 0.75, 0.75)),
    )


@configclass
class ObservationsCfg:
    @configclass
    class Policy(ObsGroup):
        joint_pos = ObsTerm(func=mdp.joint_pos_rel)
        joint_vel = ObsTerm(func=mdp.joint_vel_rel)
        actions = ObsTerm(func=mdp.last_action)
        # jack
        pose_command = ObsTerm(func=mdp.generated_commands, params={"command_name": "target_on_log"})
        pose_command_ee = ObsTerm(func=mdp.generated_commands, params={"command_name": "ee_pose"})

        def __post_init__(self):
            self.enable_corruption = True
            self.concatenate_terms = True

    policy: Policy = Policy()


@configclass
class ActionsCfg:

    arm_action = DifferentialInverseKinematicsActionCfg(
    asset_name="robot",
    joint_names=[
        "revolute_cabin","revolute_lift","revolute_tilt",
        "revolute_scoop","revolute_gripper",
    ],
    body_name="gripper_frame",
    controller=DifferentialIKControllerCfg(
        command_type="pose",
        use_relative_mode=True,
        ik_method="dls",
    ),
    scale=0.0005,  # 从 0.002 降到 0.0005，直接让每步更“小”
    body_offset=DifferentialInverseKinematicsActionCfg.OffsetCfg(
        pos=[0.0, 0.0, -0.115]
    ),
    )

    #
    gripper_action = mdp.BinaryJointPositionActionCfg(
        asset_name="robot",
        joint_names=["revolute_claw_.*"],
        open_command_expr={"revolute_claw_.*": 0.2},
        close_command_expr={"revolute_claw_.*": 0.0},
    )


@configclass
class EventCfg:
    # ① 全场景默认重置（清除历史/父级矩阵/缓存），顺序必须最前
    # 使用“只加一次 env 原点”的新实现
    reset_all = EventTerm(func=mdp.reset_scene_to_default, mode="reset")

    # ② 关节重置
    reset_robot_joints = EventTerm(
        func=mdp.reset_joints_by_scale, mode="reset",
        params={"position_range": (0.2, 0.3), "velocity_range": (0.0, 0.0)},
    )

    # ③ 机器人根姿态——贴地 2cm
    # 使用事件包装（签名兼容 EventManager，内部转到 *_new）
    reset_robot_pose = EventTerm(
        func=mdp.reset_root_state_uniform, mode="reset",
        params={
            "pose_range": {"x": (0.0, 0.0), "y": (0.0, 0.0), "z": (0.02, 0.02),
                           "roll": (0.0, 0.0), "pitch": (0.0, 0.0), "yaw": (0.0, 0.0)},
            "velocity_range": {},
            "asset_cfg": SceneEntityCfg("robot"),
        },
    )

    # ④ log（木桩）——靠近机器人正前方、离地 3cm
    # 同样使用事件包装，避免 env 原点重复叠加
    reset_log_pose = EventTerm(
        func=mdp.reset_root_state_uniform, mode="reset",
        params={
            # x 往前移到 0.30 ~ 0.36；y 保持 ±4cm；z=3cm
            "pose_range": {"x": (0.30, 0.36), "y": (-0.04, 0.04), "z": (0.03, 0.03),
                           "roll": (0.0, 0.0), "pitch": (0.0, 0.0), "yaw": (0.0, 0.0)},
            "velocity_range": {},
            "asset_cfg": SceneEntityCfg("log"),
        },
    )


@configclass
class CommandsCfg:
    # 训练真正使用的世界系 ee 目标 —— 贴近木桩区域（并且不频繁跳）
    ee_pose = mdp.UniformPoseCommandCfg(
        asset_name="robot",
        body_name="gripper_frame",
        resampling_time_range=(8.0, 8.0),
        debug_vis=True,
        ranges=mdp.UniformPoseCommandCfg.Ranges(
            pos_x=(0.32, 0.34),  # 跟木桩 x 差不多
            pos_y=(-0.02, 0.02),
            pos_z=(0.11, 0.13),
            roll=(0.0, 0.0), pitch=(0.0, 0.0), yaw=(0.0, 0.0),
        ),
    )

    # log 上的局部目标可以保留（范围也略收紧以匹配视觉）
    target_on_log = mdp.UniformPoseCommandCfg(
        asset_name="log",
        body_name="Log",
        resampling_time_range=(6.0, 6.0),
        debug_vis=True,
        ranges=mdp.UniformPoseCommandCfg.Ranges(
            pos_x=(-0.03, 0.03), pos_y=(-0.06, 0.02), pos_z=(0.08, 0.14),
            roll=(0.0, 0.0), pitch=(0.0, 0.0), yaw=(0.0, 0.0),
        ),
    )


@configclass
class TerminationsCfg:
    time_out = DoneTerm(func=mdp.time_out, time_out=True)
    object_dropping = DoneTerm(
        func=mdp.root_height_below_minimum,
        params={"minimum_height": -0.05, "asset_cfg": SceneEntityCfg("log")},
    )
    root_oob = DoneTerm(
        func=mdp.root_position_out_of_bounds,
        params={"asset_cfg": SceneEntityCfg("robot"),
                "bounds": {"x": (-2.0, 2.0), "y": (-2.0, 2.0), "z": (-1.0, 2.0)}}
    )
    ee_speed_oob = DoneTerm(
        func=mdp.ee_speed_above_limit,
        params={"asset_cfg": SceneEntityCfg("robot"),
                "ee_body_name": "gripper_frame",
                "limit_lin": 6.0, "limit_ang": 35.0}
    )
    # 新增：任一刚体越界
    any_link_oob = DoneTerm(
        func=mdp.any_body_pos_out_of_bounds,
        params={"asset_cfg": SceneEntityCfg("robot"), "bound": 2.5}  # 2.5m 足够宽
    )
    # 新增：NaN/Inf 保险丝
    nan_inf_guard = DoneTerm(
        func=mdp.has_nan_or_inf,
        params={"asset_cfg": SceneEntityCfg("robot")}
    )
    any_link_speed_oob = DoneTerm(
        func=mdp.any_body_speed_oob,
        params={"asset_cfg": SceneEntityCfg("robot"),
                "limit_lin": 2.0, "limit_ang": 10.0},  # 临时很严
    )


@configclass
class RewardsCfg:
    # 有界正向奖励：越接近 ee_pose 越接近 1
    end_effector_position_tracking_fine_grained = RewTerm(
        func=mdp_isaac.position_command_error_tanh,
        weight=1.0,   # ← 正权重
        params={"asset_cfg": SceneEntityCfg("robot", body_names=["gripper_frame"]),
                "std": 0.15, "command_name": "ee_pose"},  # std 稍大，宽容些
    )
    # 轻微动作惩罚（加重一点，抑制暴冲）
    action_rate = RewTerm(func=mdp.action_rate_l2, weight=-0.0001)
    # （可选，辅助稳定）几何距离奖励（你已实现 env-local 的稳定版本）
    reaching_log = RewTerm(func=mdp.ee_to_log_distance, weight=0.5)


@configclass
class MasiIkReachLogEnvCfg(ManagerBasedRLEnvCfg):
    scene: MasiLogSceneCfg = MasiLogSceneCfg(num_envs=1024, env_spacing=2.5)
    observations: ObservationsCfg = ObservationsCfg()
    actions: ActionsCfg = ActionsCfg()
    rewards: RewardsCfg = RewardsCfg()
    terminations: TerminationsCfg = TerminationsCfg()
    events: EventCfg = EventCfg()
    commands: CommandsCfg = CommandsCfg()

    def __post_init__(self):
        super().__post_init__()
        # Robot with higher PD stiffness for IK tracking
        self.scene.robot = MASI_CFG.replace(prim_path="{ENV_REGEX_NS}/Robot")
        # ↓ 让根链接离地 2cm（别太大，否则看起来悬空）
        self.scene.robot.init_state.pos = (0.0, 0.0, 0.02)
        self.scene.robot.init_state.rot = (1.0, 0.0, 0.0, 0.0)

        # Rollout settings
        # self.fix_base = True  # jack add
        self.sim.dt = 0.01  # 100Hz
        self.decimation = 1
        self.episode_length_s = 3.0
        self.sim.render_interval = self.decimation
        # (Names may vary by Isaac Lab version; use existing fields)
        self.sim.physx.enable_stabilization = True
        self.sim.physx.enable_enhanced_determinism = True
        self.sim.physx.bounce_threshold_velocity = 0.2
        self.sim.physx.bounce_threshold_velocity = 0.01
        self.sim.physx.gpu_found_lost_aggregate_pairs_capacity = 1024 * 1024 * 4
        self.sim.physx.gpu_total_aggregate_pairs_capacity = 16 * 1024
        self.sim.physx.friction_correlation_distance = 0.00625
        self.enable_corruption = False  # jack add

        # 让 Viewer 锁到第 0 个 env，避免渲染跨很大 world 偏移
        self.viewer.origin_type = "env"
        self.viewer.env_index = 0

        # （可选）减轻渲染开销
        if hasattr(self.sim, "render"):
            self.sim.render.enable_shadows = False
            self.sim.render.enable_ambient_occlusion = False
            self.sim.render.enable_direct_lighting = True


@configclass
class MasiIkReachLogEnvCfg_PLAY(MasiIkReachLogEnvCfg):
    def __post_init__(self):
        super().__post_init__()
        # Smaller scene for quick runs
        self.scene.num_envs = 32
        self.scene.env_spacing = 2.5
        # Disable observation corruption for play
        self.observations.policy.enable_corruption = False
