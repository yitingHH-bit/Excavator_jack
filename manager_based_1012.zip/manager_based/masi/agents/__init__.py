"""Agent configs for MASI tasks (rl_games, etc.)."""

