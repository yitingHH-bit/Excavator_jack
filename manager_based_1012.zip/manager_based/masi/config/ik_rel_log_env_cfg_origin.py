from dataclasses import MISSING

import isaaclab.sim as sim_utils
from isaaclab.assets import ArticulationCfg, AssetBaseCfg, RigidObjectCfg
from isaaclab.controllers.differential_ik_cfg import DifferentialIKControllerCfg
from isaaclab.envs import ManagerBasedRLEnvCfg
from isaaclab.envs.mdp.actions.actions_cfg import DifferentialInverseKinematicsActionCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import RewardTermCfg as RewTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.utils import configclass
import isaaclab_tasks.manager_based.manipulation.reach.mdp as mdp_isaac
from isaaclab_assets.robots.masiV0 import MASI_CFG

from .. import mdp

# ---------------------------------------------------------------------------
# 安全补丁（修正 Hydra 序列化问题：保留原函数的 __name__/__module__）
# ---------------------------------------------------------------------------
import torch
from functools import wraps

# 1) 给 mdp_isaac.position_command_error_tanh 加“有界+去 NaN/Inf”的安全包裹
if hasattr(mdp_isaac, "position_command_error_tanh"):
    _orig_pos_cmd_err_tanh = mdp_isaac.position_command_error_tanh

    @wraps(_orig_pos_cmd_err_tanh)
    def _safe_pos_cmd_err_tanh(*args, **kwargs):
        out = _orig_pos_cmd_err_tanh(*args, **kwargs)
        out = torch.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)
        return out.clamp_(0.0, 1.0)

    # 保留原始模块归属，避免被序列化成当前模块的匿名函数
    _safe_pos_cmd_err_tanh.__module__ = _orig_pos_cmd_err_tanh.__module__
    _safe_pos_cmd_err_tanh.__qualname__ = _orig_pos_cmd_err_tanh.__qualname__
    _safe_pos_cmd_err_tanh.__name__ = _orig_pos_cmd_err_tanh.__name__
    mdp_isaac.position_command_error_tanh = _safe_pos_cmd_err_tanh

# 2) 对四个观测项做统一“去 NaN/Inf + 限幅”，并把包装函数的元数据设回原函数
def _sanitize_obs_fn(fn, clip=100.0):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        x = fn(*args, **kwargs)
        if not torch.is_tensor(x):
            x = torch.as_tensor(x, device=getattr(x, "device", None))
        x = torch.nan_to_num(x, nan=0.0, posinf=clip, neginf=-clip)
        return x.clamp_(-clip, clip)

    # 关键：保持可序列化的“模块:函数名”仍指向原始定义
    wrapped.__module__ = fn.__module__
    wrapped.__qualname__ = fn.__qualname__
    wrapped.__name__ = fn.__name__
    return wrapped

for _name in ["joint_pos_rel", "joint_vel_rel", "last_action", "generated_commands"]:
    if hasattr(mdp, _name):
        setattr(mdp, _name, _sanitize_obs_fn(getattr(mdp, _name)))
# ---------------------------------------------------------------------------


@configclass
class MasiLogSceneCfg(InteractiveSceneCfg):
    """Scene with MASI and a simple log object to reach."""

    robot: ArticulationCfg = MISSING
    log: RigidObjectCfg = RigidObjectCfg(
        prim_path="{ENV_REGEX_NS}/Log",
        spawn=sim_utils.CuboidCfg(
            size=(0.06, 0.20, 0.06),
            rigid_props=sim_utils.RigidBodyPropertiesCfg(
                max_linear_velocity=10.0,    # m/s
                max_angular_velocity=30.0,
            ),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.100),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.1, 0.0)),
        ),
        # place on ground: center at z ~ half thickness (0.03)
        init_state=RigidObjectCfg.InitialStateCfg(pos=(0.6, 0.0, 0.03), rot=(1.0, 0.0, 0.0, 0.0)),
    )

    plane = AssetBaseCfg(
        prim_path="/World/GroundPlane",
        init_state=AssetBaseCfg.InitialStateCfg(),
        spawn=sim_utils.GroundPlaneCfg(),
    )

    light = AssetBaseCfg(
        prim_path="/World/Light",
        spawn=sim_utils.DomeLightCfg(intensity=3000.0, color=(0.75, 0.75, 0.75)),
    )


@configclass
class ObservationsCfg:
    @configclass
    class PolicyCfg(ObsGroup):
        joint_pos = ObsTerm(func=mdp.joint_pos_rel)
        joint_vel = ObsTerm(func=mdp.joint_vel_rel)
        actions = ObsTerm(func=mdp.last_action)
        # jack
        pose_command = ObsTerm(func=mdp.generated_commands, params={"command_name": "target_on_log"})
        pose_command_ee = ObsTerm(func=mdp.generated_commands, params={"command_name": "ee_pose"})

        def __post_init__(self):
            # 统一与环境保持一致：关闭 corruption（避免脏观测）
            self.enable_corruption = False
            self.concatenate_terms = True

    policy: PolicyCfg = PolicyCfg()


@configclass
class ActionsCfg:
    arm_action = DifferentialInverseKinematicsActionCfg(
        asset_name="robot",
        joint_names=[
            "revolute_cabin","revolute_lift","revolute_tilt",
            "revolute_scoop","revolute_gripper",
        ],
        body_name="gripper_frame",
        controller=DifferentialIKControllerCfg(
            command_type="pose",
            use_relative_mode=True,
            ik_method="dls",
        ),
        # （保持你当前文件的设置）较小步长可提升稳定性
        scale=0.0005,
        body_offset=DifferentialInverseKinematicsActionCfg.OffsetCfg(
            pos=[0.0, 0.0, -0.115]
        ),
    )

    gripper_action = mdp.BinaryJointPositionActionCfg(
        asset_name="robot",
        joint_names=["revolute_claw_.*"],
        open_command_expr={"revolute_claw_.*": 0.2},
        close_command_expr={"revolute_claw_.*": 0.0},
    )


@configclass
class EventCfg:
    # 不改你的事件定义
    reset_all = EventTerm(func=mdp.reset_scene_to_default, mode="reset")
    reset_robot_joints = EventTerm(
        func=mdp.reset_joints_by_scale, mode="reset",
        params={"position_range": (0.2, 0.3), "velocity_range": (0.0, 0.0)},
    )
    reset_robot_pose = EventTerm(
        func=mdp.reset_root_state_uniform, mode="reset",
        params={
            "pose_range": {"x": (0.0, 0.0), "y": (0.0, 0.0), "z": (0.02, 0.02),
                           "roll": (0.0, 0.0), "pitch": (0.0, 0.0), "yaw": (0.0, 0.0)},
            "velocity_range": {},
            "asset_cfg": SceneEntityCfg("robot"),
        },
    )
    # ④ log（木桩）——进一步靠近机器人
    # ① log：再往里收一档
    reset_log_pose = EventTerm(
    func=mdp.reset_root_state_uniform, mode="reset",
    params={
        # 原 (0.16, 0.20) → 更近一档
        "pose_range": {"x": (0.12, 0.16), "y": (-0.010, 0.010), "z": (0.03, 0.03),
                       "roll": (0.0, 0.0), "pitch": (0.0, 0.0), "yaw": (0.0, 0.0)},
        "velocity_range": {},
        "asset_cfg": SceneEntityCfg("log"),
    },
)




@configclass
class CommandsCfg:
   # 训练使用的世界系 ee 目标 —— 跟着更近的 log
    ee_pose = mdp.UniformPoseCommandCfg(
    asset_name="robot",
    body_name="gripper_frame",
    resampling_time_range=(8.0, 8.0),
    debug_vis=True,
    ranges=mdp.UniformPoseCommandCfg.Ranges(
        pos_x=(0.23, 0.25),   # 原 (0.32, 0.34) → 往回收
        pos_y=(-0.015, 0.015),
        pos_z=(0.11, 0.12),
        roll=(0.0, 0.0), pitch=(0.0, 0.0), yaw=(0.0, 0.0),
    ),
)

# log 上的局部目标也对应收紧到中间区域
    target_on_log = mdp.UniformPoseCommandCfg(
    asset_name="log",
    body_name="Log",
    resampling_time_range=(6.0, 6.0),
    debug_vis=True,
    ranges=mdp.UniformPoseCommandCfg.Ranges(
        pos_x=(-0.02, 0.02), pos_y=(-0.02, 0.02), pos_z=(0.08, 0.12),
        roll=(0.0, 0.0), pitch=(0.0, 0.0), yaw=(0.0, 0.0),
    ),
)


@configclass
class TerminationsCfg:
    time_out = DoneTerm(func=mdp.time_out, time_out=True)
    object_dropping = DoneTerm(
        func=mdp.root_height_below_minimum,
        params={"minimum_height": -0.05, "asset_cfg": SceneEntityCfg("log")},
    )
    root_oob = DoneTerm(
        func=mdp.root_position_out_of_bounds,
        params={"asset_cfg": SceneEntityCfg("robot"),
                "bounds": {"x": (-2.0, 2.0), "y": (-2.0, 2.0), "z": (-1.0, 2.0)}}
    )
    ee_speed_oob = DoneTerm(
        func=mdp.ee_speed_above_limit,
        params={"asset_cfg": SceneEntityCfg("robot"),
                "ee_body_name": "gripper_frame",
                "limit_lin": 6.0, "limit_ang": 35.0}
    )
    any_link_oob = DoneTerm(
        func=mdp.any_body_pos_out_of_bounds,
        params={"asset_cfg": SceneEntityCfg("robot"), "bound": 2.5}
    )
    nan_inf_guard = DoneTerm(
        func=mdp.has_nan_or_inf,
        params={"asset_cfg": SceneEntityCfg("robot")}
    )
    any_link_speed_oob = DoneTerm(
        func=mdp.any_body_speed_oob,
        params={"asset_cfg": SceneEntityCfg("robot"),
                "limit_lin": 2.0, "limit_ang": 10.0},
    )


@configclass
class RewardsCfg:
    end_effector_position_tracking_fine_grained = RewTerm(
        func=mdp_isaac.position_command_error_tanh,   # 已通过安全包裹
        weight=1.0,
        params={"asset_cfg": SceneEntityCfg("robot", body_names=["gripper_frame"]),
                "std": 0.15, "command_name": "ee_pose"},
    )
    action_rate = RewTerm(func=mdp.action_rate_l2, weight=-0.0001)
    reaching_log = RewTerm(func=mdp.ee_to_log_distance, weight=0.5)  # 使用安全版实现


@configclass
class MasiIkReachLogEnvCfg(ManagerBasedRLEnvCfg):
    scene: MasiLogSceneCfg = MasiLogSceneCfg(num_envs=1024, env_spacing=2.5)
    observations: ObservationsCfg = ObservationsCfg()
    actions: ActionsCfg = ActionsCfg()
    rewards: RewardsCfg = RewardsCfg()
    terminations: TerminationsCfg = TerminationsCfg()
    events: EventCfg = EventCfg()
    commands: CommandsCfg = CommandsCfg()

    def __post_init__(self):
        super().__post_init__()
        self.scene.robot = MASI_CFG.replace(prim_path="{ENV_REGEX_NS}/Robot")
        self.scene.robot.init_state.pos = (0.0, 0.0, 0.02)
        self.scene.robot.init_state.rot = (1.0, 0.0, 0.0, 0.0)

        self.sim.dt = 0.01  # 100Hz
        self.decimation = 2
        self.episode_length_s = 3.0
        self.sim.render_interval = self.decimation
        # self.sim.physx.enable_stabilization = True
        # self.sim.physx.enable_enhanced_determinism = True
        # self.sim.physx.bounce_threshold_velocity = 0.2
        # self.sim.physx.bounce_threshold_velocity = 0.01
        # self.sim.physx.gpu_found_lost_aggregate_pairs_capacity = 1024 * 1024 * 4
        # self.sim.physx.gpu_total_aggregate_pairs_capacity = 16 * 1024
        # self.sim.physx.friction_correlation_distance = 0.00625
        # self.enable_corruption = False

        # self.viewer.origin_type = "env"
        # self.viewer.env_index = 0

        if hasattr(self.sim, "render"):
            self.sim.render.enable_shadows = False
            self.sim.render.enable_ambient_occlusion = False
            self.sim.render.enable_direct_lighting = True


@configclass
class MasiIkReachLogEnvCfg_PLAY(MasiIkReachLogEnvCfg):
    def __post_init__(self):
        super().__post_init__()
        self.scene.num_envs = 32
        self.scene.env_spacing = 2.5
        self.observations.policy.enable_corruption = False
