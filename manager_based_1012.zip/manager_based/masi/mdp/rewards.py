from __future__ import annotations
import torch
from isaaclab.managers import SceneEntityCfg
from isaaclab.utils.math import matrix_from_quat  # 仍然可用
import math

# 共用小工具：数值护栏
def _safe(x: torch.Tensor, name: str = "") -> torch.Tensor:
    x = torch.nan_to_num(x, nan=0.0, posinf=1e6, neginf=-1e6)
    return torch.clamp(x, -1e3, 1e3)

def _safe_div(num: torch.Tensor, den: torch.Tensor) -> torch.Tensor:
    return num / (den + 1e-8)

def _get_env_origins(env) -> torch.Tensor:
    origins = env.scene.env_origins
    return origins if isinstance(origins, torch.Tensor) else torch.as_tensor(origins, device=env.device)

def ee_to_log_distance(
    env,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    log_cfg: SceneEntityCfg   = SceneEntityCfg("log"),
    ee_body_name: str         = "gripper_frame",
    ee_offset_local: tuple[float, float, float] = (0.0, 0.0, -0.115),
    use_l2: bool = True,
    shaped: bool = True,
    scale: float = 0.25,
) -> torch.Tensor:
    """有界奖励（0~1，越近越接近 1）或负距离（越近越大），兼容 (N,B,3/4) 张量结构。"""
    device = env.device
    origins = _get_env_origins(env)  # (N,3)

    robot = env.scene[robot_cfg.name]
    log   = env.scene[log_cfg.name]

    # —— 按名字解析 body 索引（单个） ——
    body_ids, _ = robot.find_bodies([ee_body_name])
    ee_idx = int(body_ids[0])

    # —— 世界系 EE 位姿（按张量维度取） ——
    ee_pos_w  = robot.data.body_link_pos_w[:, ee_idx, :]   # (N,3)
    ee_quat_w = robot.data.body_link_quat_w[:, ee_idx, :]  # (N,4)

    # 加局部 offset（旋转到世界）
    R_ee = matrix_from_quat(ee_quat_w)                     # (N,3,3)
    ee_off = torch.as_tensor(ee_offset_local, device=device, dtype=ee_pos_w.dtype).view(1,3,1)
    ee_pos_w = ee_pos_w + (R_ee @ ee_off).squeeze(-1)      # (N,3)

    # —— 世界系 LOG 根位置，兼容 (N,3) / (N,1,3) ——
    log_root = log.data.root_pos_w
    if log_root.ndim == 2:
        log_pos_w = log_root
    elif log_root.ndim == 3:
        log_pos_w = log_root[:, 0, :]
    else:
        log_pos_w = log_root.reshape(log_root.shape[0], -1)[..., :3]

    # —— 转 env 局部，避免世界大偏移 ——
    ee_pos_local  = ee_pos_w  - origins
    log_pos_local = log_pos_w - origins

    # —— 距离 & 有界形状化 ——
    d = _safe(ee_pos_local - log_pos_local, "d_vec")
    dist = torch.linalg.norm(d, dim=1) if use_l2 else torch.sum(torch.abs(d), dim=1)
    dist = _safe(dist, "dist")

    if shaped:
        rew = 1.0 - torch.tanh(_safe_div(dist, torch.as_tensor(scale, device=device)))
        return _safe(rew, "ee2log_shaped")
    else:
        rew = -_safe_div(dist, torch.as_tensor(scale, device=device))
        return _safe(rew, "ee2log_raw")
# 放在 rewards.py 里（和 ee_to_log_distance 同文件）
def safe_action_rate_l2(env, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
                        clip_per_step: float = 1.0):
    """
    对动作差分做 L2，并且数值保底+裁剪，避免单步出现大爆点。
    """
    robot = env.scene[asset_cfg.name]
    # 用 env 自带缓存/上一帧动作；Isaac Lab 通常通过 manager 传入 self._processed_actions
    # 这里做一个“可用则用”的降级逻辑：
    try:
        a = env.action_manager.raw_actions  # (N, A)：若版本支持
    except Exception:
        # 退化到 0（不会产生大惩罚）
        import torch
        a = torch.zeros_like(robot.data.joint_pos[..., :1])

    import torch
    if not torch.is_tensor(a):
        a = torch.as_tensor(a, device=env.device)

    # 差分近似（本帧-上一帧），没有上一帧就当 0
    if not hasattr(env, "_prev_actions"):
        env._prev_actions = torch.zeros_like(a)
    da = a - env._prev_actions
    env._prev_actions = a.detach()

    # L2 + 数值安全 + 裁剪
    da = torch.nan_to_num(da, nan=0.0, posinf=0.0, neginf=0.0)
    per_env = torch.sum(da * da, dim=1)
    per_env = torch.clamp(per_env, 0.0, clip_per_step)  # 每步最多 1.0（配合负权重）
    return per_env

def cabin_yaw_aligns_target(env, *, robot_name="robot", log_name="log", eps: float = 1e-6):
    """奖励底座(revolute_cabin)朝向对齐 base→log 的方位角。返回 [N]，1=完美对齐。"""
    device = env.device
    rob = env.scene[robot_name]
    log = env.scene[log_name]

    # ---- 取 root state（兼容不同字段名） ----
    def _root_state(data):
        if hasattr(data, "root_state_w"):
            return data.root_state_w
        if hasattr(data, "root_state"):
            return data.root_state
        raise AttributeError("ArticulationData缺少root_state(_w)")

    rs_robot = _root_state(rob.data)  # (N,13)
    rs_log   = _root_state(log.data)  # (N,13)

    base_xy = rs_robot[:, 0:2]   # (N,2)
    log_xy  = rs_log[:, 0:2]     # (N,2)
    vec     = log_xy - base_xy
    desired = torch.atan2(vec[:, 1], vec[:, 0])   # (N,)

    # ---- 取 cabin 关节角（用 joint_pos，而不是 joint_pos_w）----
    if not hasattr(env, "_cabin_joint_idx"):
        names = list(rob.data.joint_names)
        idx = -1
        for i, n in enumerate(names):
            s = n.decode("utf-8") if isinstance(n, (bytes, bytearray)) else str(n)
            if s == "revolute_cabin":
                idx = i
                break
        if idx < 0:
            for i, n in enumerate(names):
                s = n.decode("utf-8") if isinstance(n, (bytes, bytearray)) else str(n)
                if "cabin" in s.lower():
                    idx = i
                    break
        env._cabin_joint_idx = int(idx) if idx >= 0 else None
        if env._cabin_joint_idx is None and not hasattr(env, "_warn_no_cabin"):
            print("[WARN] cabin_yaw_aligns_target: 未找到 'revolute_cabin'，奖励将恒为0")
            env._warn_no_cabin = True

    if env._cabin_joint_idx is None:
        return torch.zeros_like(desired)

    jidx = env._cabin_joint_idx

    # joint_pos shape: (N, DoF)
    q = rob.data.joint_pos
    if not torch.is_tensor(q):
        q = torch.as_tensor(q, device=device)
    yaw = q[:, jidx]   # (N,)

    # ---- 角差映射到[0,1] ----
    err = (yaw - desired + math.pi) % (2 * math.pi) - math.pi
    return 0.5 * (torch.cos(err).clamp(-1.0, 1.0) + 1.0)

# mdp.py 里（和 reset_joints_by_scale、ee_to_log_distance 那些函数放一起）

import torch
from isaaclab.envs import ManagerBasedRLEnv
from isaaclab.managers import SceneEntityCfg
from isaaclab.assets import RigidObject
from isaaclab.utils.math import combine_frame_transforms


def move_log_under_command(
    env: ManagerBasedRLEnv,
    env_ids: torch.Tensor,
    command_name: str,
    robot_asset_cfg: SceneEntityCfg,
    log_asset_cfg: SceneEntityCfg,
    log_height: float = 0.04,
) -> None:
    """把 log 移到命令末端正下方，使 log 始终跟随 ee_pose 命令."""
    device = env.device

    # 统一 env_ids 类型
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)

    if env_ids.numel() == 0:
        return

    robot = env.scene[robot_asset_cfg.name]
    log: RigidObject = env.scene[log_asset_cfg.name]  # type: ignore

    # 1) 取当前命令（只取这些 env）
    cmd_all = env.command_manager.get_command(command_name)   # [num_envs, k]
    cmd = cmd_all[env_ids]                                   # [N, k]
    des_pos_b = cmd[:, :3]                                   # [N, 3]

    # 2) 用对应 env 的 root pose 转到世界坐标
    root_pos = robot.data.root_state_w[env_ids, 0:3]         # [N, 3]
    root_quat = robot.data.root_state_w[env_ids, 3:7]        # [N, 4]
    des_pos_w, _ = combine_frame_transforms(
        root_pos,
        root_quat,
        des_pos_b,
    )                                                        # [N, 3]

    # 3) log 中心要比命令点低一半高度
    new_log_pos = des_pos_w.clone()
    new_log_pos[:, 2] -= 0.5 * log_height

    # 4) 只对这些 env 的 root_state 做修改
    root_state_local = log.data.root_state_w[env_ids].clone()  # [N, 13]
    root_state_local[:, 0:3] = new_log_pos
    root_state_local[:, 7:13] = 0.0  # 线速度/角速度清零

    # 5) 写回仿真（现在 root_state_local 的 batch 维度和 env_ids 匹配）
    log.write_root_state_to_sim(root_state_local, env_ids=env_ids)
